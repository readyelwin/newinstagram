//
//  ContentView.swift
//  Instagram
//
//  Created by user167669 on 3/30/20.
//  Copyright © 2020 user167669. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
